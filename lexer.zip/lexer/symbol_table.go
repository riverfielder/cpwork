package lexer

// NewSymbolTable 初始化符号表
func NewSymbolTable() *SymbolTable {
    st := &SymbolTable{
        Keywords:    make(map[string]TokenType),
        Identifiers: make(map[string]int),
        Constants:   make(map[string]float64),
        Operators:   make(map[string]TokenType),
        Delimiters:  make(map[string]TokenType),
    }
    
    // 初始化关键字表
    st.Keywords["if"] = IF
    st.Keywords["then"] = THEN
    st.Keywords["else"] = ELSE
    
    // 初始化运算符表
    st.Operators["+"] = PLUS
    st.Operators["-"] = MINUS
    st.Operators["*"] = MULTIPLY
    st.Operators["/"] = DIVIDE
    st.Operators["="] = ASSIGN
    st.Operators[">"] = GT
    st.Operators["<"] = LT
    st.Operators["=="] = EQ
    
    // 初始化界符表
    st.Delimiters["("] = LPAREN
    st.Delimiters[")"] = RPAREN
    st.Delimiters[";"] = SEMICOLON
    
    return st
}